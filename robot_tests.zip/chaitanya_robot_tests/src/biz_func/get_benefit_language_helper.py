# Configuration parser import from relative path
import sys, os
sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../.."))
import src.utilities.config_parser as config
import src.utilities.rest_client as rest_client
import src.utilities.xml_utils as xml_utils


def api_call(body):
    """Process API call and return the response object
    
    Arguments:
        body {str} -- Request XML as string
    
    Returns:
        <Response> -- Returns response object
    """

    endpoint = config.get_endpoint_config("RUN")['endpoint']
    resource_path = config.get_resources_config('TREX')['getBenefitLanguageRequestMsg']
    bearer_token = config.get_headers_config('HEADERS')['bearer']
    url = f"{endpoint}{resource_path}"
    headers = {
        'Content-Type': 'application/xml',\
        'authorization' : f'bearer {bearer_token}',\
        'actor': 'oil',\
        'scope': 'polaris-eligibility-propel-all'\
    }
    resp = rest_client.post(url=url, data=body, headers=headers)
    print(f"getBenefitLanguageRequestMsg : ", rest_client.log_request(resp.request))
    print(f"getBenefitLanguageResponseMsg : ", rest_client.log_response(resp.content))
    return resp


def construct_xml_request(data_dict):
    """Construct XML request based on the input dictionary
    
    Arguments:
        data_dict {dict} -- Input data to be set in request XML
                            dummy_dict = {'identifierTypeCode':'KONDASAMY', 'individualIdentifier': '000000000'}
    
    Returns:
        [str] -- XML formatted request with corresponding data set
    """

    xml_output = xml_utils.set_xml_values_for_request('getBenefitLanguageRequestMsg', data_dict)
    return xml_output


def get_benefit_language(data_dict):
    """Wrapper function for <getBenefitLanguageRequestMsg>
    
    Arguments:
        data_dict {dict} -- Input data to be set in request XML
                            dummy_dict = {'identifierTypeCode':'KONDASAMY', 'individualIdentifier': '000000000'}

    Returns:
        <Response> -- Returns response object
    """
    xml_request = construct_xml_request(data_dict)
    return api_call(xml_request)


def get_list_data_from_response(response, xpath):
    """ Get the XML element text for the given XPATH

    Arguments:
        response {str} -- <ElementTree> processed by lxml on Response
        xpath {str} -- XPATH
    
    Returns:
        data_list - Returns a list of strings
    """
    xml_etree = xml_utils.get_parsed_xml_from_response(response)
    element_list = xml_utils.get_elements_as_list(xml_etree, xpath)
    data_list = None
    if element_list:
        data_list = [element.text for element in element_list]
    return data_list


def get_single_node_data_from_response(response, xpath):
    """Get the data of a single XML element text for the given XPATH

    Arguments:
        response {str} -- <ElementTree> processed by lxml on Response
        xpath {str} -- XPATH
    
    Returns:
        data - Returns first element from list of strings
    """

    data_list = get_list_data_from_response(response, xpath)
    if data_list:
        return data_list[0]
    else:
        return None


if __name__ == "__main__":
    dummy_dict = {'identifierTypeCode':'KONDASAMY', 'individualIdentifier': '000000000'}
    response = get_benefit_language(dummy_dict)

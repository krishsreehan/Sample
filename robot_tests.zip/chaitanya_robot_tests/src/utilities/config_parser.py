import configparser
import os.path


def get_endpoint_config(env):
    """Get endpoint related configurations and filter based on the key
    """
    print(f"Fetching test environment details..")
    config = configparser.ConfigParser()
    cur_path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(cur_path, "../config/endpoint.ini")
    with open(path) as f:
        config.read_file(f)
    return(config._sections[env])


def get_resources_config(env):
    """Get resource path related configurations and filter based on the key
    """
    print(f"Fetching resource path details..")
    config = configparser.ConfigParser()
    cur_path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(cur_path, "../config/resources.ini")
    with open(path) as f:
        config.read_file(f)
    return(config._sections[env])


def get_headers_config(env):
    """Get bearer token configurations
    """
    print(f"Fetching header details..")
    config = configparser.ConfigParser()
    cur_path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(cur_path, "../config/headers.ini")
    with open(path) as f:
        config.read_file(f)
    return(config._sections[env])


if __name__ == '__main__':
    print(get_endpoint_config('RUN'))
    print(get_resources_config('API'))
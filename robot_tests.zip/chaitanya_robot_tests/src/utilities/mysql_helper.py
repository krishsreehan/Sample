import ConfigParser
import pymysql
from robot.api import logger

def connect_to_database(dbName=None,
                        dbUsername=None,
                        dbPassword=None,
                        dbHost=None,
                        dbPort=3306,
                        dbCharset='utf8mb4',
                        dbConfigFile='./config/mysql_db.cfg'):
    """
    Connect to a MySQL database
    Arguments:
    - dbName: database name
    - dbUsername: database user name
    - dbUsername: database password
    - dbHost: hostname or IP address of the database
    - dbPort: database port number (default=6379)
    - dbCharset: character set (default='utf8mb4')
    - dbConfigFile: MySql data config file
    Return MySql dabase connection object
    """
    config = ConfigParser.ConfigParser()
    config.read([dbConfigFile])

    dbName = dbName or config.get('default', 'dbName')
    dbUsername = dbUsername or config.get('default', 'dbUsername')
    dbPassword = dbPassword if dbPassword is not None else config.get(
        'default', 'dbPassword')
    dbHost = dbHost or config.get('default', 'dbHost') or 'localhost'
    dbPort = int(dbPort or config.get('default', 'dbPort'))
    print(
        f'Connecting using : {dbName}.connect(db={dbName}, \
        user={dbUsername}, passwd={dbPassword}, host={dbHost}, \
        port={dbPort}, charset={dbCharset})')
    try:
        db_connection = pymysql.connect(
            db=dbName,
            user=dbUsername,
            passwd=dbPassword,
            host=dbHost,
            port=dbPort,
            charset=dbCharset)
        return db_connection
    except Exception:
        return None


def disconnect_from_database(db_connection=None):
    """
    Disconnects from the database.
    Arguments:
    - db_connection: database connection object
    """
    print('Executing : Disconnect From Database')
    if not db_connection:
        db_connection.close()


def query(db_connection, selectStatement, sansTran=False, returnAsDict=False):
    """
    Uses the input `selectStatement` to query for the values that will be returned as a list of tuples. Set optional
    input `sansTran` to True to run command without an explicit transaction commit or rollback.
    Set optional input `returnAsDict` to True to return values as a list of dictionaries.
    Tip: Unless you want to log all column values of the specified rows,
    try specifying the column names in your select statements
    as much as possible to prevent any unnecessary surprises with schema
    changes and to easily see what your [] indexing is trying to retrieve
    (i.e. instead of `"select * from my_table"`, try
    `"select id, col_1, col_2 from my_table"`).
    For example, given we have a table `person` with the following data:
    | id | first_name  | last_name |
    |  1 | Franz Allan | See       |
    When you do the following:
    | @{queryResults} | Query | SELECT * FROM person |
    | Log Many | @{queryResults} |
    You will get the following:
    [1, 'Franz Allan', 'See']
    Also, you can do something like this:
    | ${queryResults} | Query | SELECT first_name, last_name FROM person |
    | Log | ${queryResults[0][1]}, ${queryResults[0][0]} |
    And get the following
    See, Franz Allan
    Using optional `sansTran` to run command without an explicit transaction commit or rollback:
    | @{queryResults} | Query | SELECT * FROM person | True |
    """
    try:
        cur = db_connection.cursor()
        logger.info('Executing : Query  |  %s ' % selectStatement)
        cur.execute(selectStatement)
        allRows = cur.fetchall()

        if returnAsDict:
            mappedRows = []
            col_names = [c[0] for c in cur.description]

            for rowIdx in range(len(allRows)):
                d = {}
                for colIdx in range(len(allRows[rowIdx])):
                    d[col_names[colIdx]] = allRows[rowIdx][colIdx]
                mappedRows.append(d)
            return mappedRows

        return allRows
    except Exception:
        print("Exception caught!")
        return None
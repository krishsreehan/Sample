import xml.etree.ElementTree as etree
import os
from lxml import etree as ltree


def get_parsed_xml_from_file(key):
    '''Returns the parsed XML object for a given key
    
    Keyword Arguments:
        key {str} -- Can be any one from the list
                    ['getMembershipRequestMsg', 'getSubscriptionServiceRequestMsg', 'getBenefitLanguageRequestMsg'] 
    '''
    if key == 'getMembershipRequestMsg':
        file_name = 'get_membership_request.xml'
    elif key == 'getSubscriptionServiceRequestMsg':
        file_name = 'get_benefit_language_request.xml'
    elif key == 'getBenefitLanguageRequestMsg':
        file_name = 'get_subscription_service_request.xml'
    cur_path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(cur_path, f'/Users/kondasamy.j/Documents/Experiments/chaitanya_robot_tests/src/resources/templates/{file_name}')
    
    with open(path, 'r') as xml_file:
        tree = etree.parse(xml_file)
    return tree


def get_parsed_xml_from_response(response_content):
    '''Parse the XML response and send as xml <ElementTree> objects
    
    Arguments:
        response_content {[str]} -- resp.text generated as part of requests
    '''
    response = ltree.fromstring(response_content)
    return response


def get_elements_as_list(response, xpath):
    '''
    Get the XML element text for the given XPATH

    Arguments:
        response {str} -- <ElementTree> processed by lxml on Response
        xpath {str} -- XPATH
    
    Returns:
        data_list - Returns a list of <Elements>
        Further processing required with .tag or .text
    '''

    # Namespace assignment based on type of request
    if 'getMembership' in response.tag:
        namespace = 'http://enterprise.optum.com/api/c360/eligibility/memberships/v1.0/read'
    elif 'getSubscriptionService' in response.tag:
        namespace = 'http://enterprise.optum.com/api/c360/eligibility/benefit-language/v4.0/read'
    elif 'getBenefitLanguage' in response.tag:
        namespace = 'http://enterprise.optum.com/api/c360/eligibility/service-benefits/v4.0/read'
    namespaces = {'ns': namespace}
    data_list = None
    
    if response.xpath(xpath, namespaces=namespaces):
        data_list = response.xpath(xpath, namespaces=namespaces)
    return data_list


def set_xml_values_for_request(key, data_dict):
    '''Set the values for the XML nodes from the respective request XML template
    
    Arguments:
        key {str} -- Should be any one from the below list
                    ['getMembershipRequestMsg', 'getSubscriptionServiceRequestMsg', 'getBenefitLanguageRequestMsg'] 
        data_dict {dict} -- Dictionary of node names to values
                    Eg: {'identifierTypeCode':'KONDASAMY', 'individualIdentifier': b'000000000'} 
    
    Returns:
        Modified XML request string  
    '''
    # Get LXML parsed object from the respective request template
    tree = get_parsed_xml_from_file(key)
    root = tree.getroot()
    # Namespace assignment based on type of request
    if key == 'getMembershipRequestMsg':
        namespace = 'http://enterprise.optum.com/api/c360/eligibility/memberships/v1.0/read'
    elif key == 'getSubscriptionServiceRequestMsg':
        namespace = 'http://enterprise.optum.com/api/c360/eligibility/benefit-language/v4.0/read'
    elif key == 'getBenefitLanguageRequestMsg':
        namespace = 'http://enterprise.optum.com/api/c360/eligibility/service-benefits/v4.0/read'
    namespaces = {'ns': namespace}

    for element, value in data_dict.items():
        root.find(f'ns:{element}', namespaces=namespaces).text = value
    return etree.tostring(root)


if __name__ == "__main__":
    # Test 1
    dummy_dict = {'identifierTypeCode':'KONDASAMY', 'individualIdentifier': '000000000'} 
    xml_output = set_xml_values_for_request('getMembershipRequestMsg', dummy_dict)
    print("XML string 1 : \n", xml_output)

    # Test 2
    dummy_dict = {'enrolleeSRK':'KONDASAMY', 'membershipTerminationDate': '979879797'} 
    xml_output = set_xml_values_for_request('getBenefitLanguageRequestMsg', dummy_dict)
    print("XML string 2 : \n", xml_output)

    # Test 3
    dummy_dict = {'packageOptionIdentifier':'KONDASAMY'} 
    xml_output = set_xml_values_for_request('getBenefitLanguageRequestMsg', dummy_dict)
    print("XML string 3 : \n", xml_output)

    # Test 4
    dummy_xml = '''<getMembershipResponseMsg xmlns="http://enterprise.optum.com/api/c360/eligibility/memberships/v1.0/read">
    <membership>
      <sourceSysCode>CR</sourceSysCode>
      <groupNumber>1198499</groupNumber>
      <groupName>A-QUICK PICK CRANE SERVICE INC</groupName>
      <marketSegmentCode>01</marketSegmentCode>
      <coverage>
         <benefitPlanId>PEDV000019</benefitPlanId>
         <benefitPlanName>PEDIATRIC VISION CTSM FREEDOM DIRECT 12</benefitPlanName>
         <coverageLevelCode>FAM</coverageLevelCode>
         <coverageLevelDescription>Family</coverageLevelDescription>
         <fundingArrangementDefinition>Fully Insured</fundingArrangementDefinition>
      </coverage>
      <coverage>
         <benefitPlanId>PEDV000020</benefitPlanId>
         <benefitPlanName>SAMY</benefitPlanName>
         <coverageLevelCode>FAM</coverageLevelCode>
         <coverageLevelDescription>Family</coverageLevelDescription>
         <fundingArrangementDefinition>Fully Insured</fundingArrangementDefinition>
      </coverage>
    </membership>
    </getMembershipResponseMsg>
    '''
    response = get_parsed_xml_from_response(dummy_xml)
    print(len(get_elements_as_list(response, '//ns:benefitPlanId[contains(text(),"PEDV000020")]/following-sibling::ns:benefitPlanName')))
    

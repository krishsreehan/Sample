import requests
from requests.auth import HTTPBasicAuth


def get_basic_auth(username=None, password=None):
    """ Generate basic authentication token
    Arguments:
        - username: user name
        - password: password
    Return basic authentication token
    """
    if username and password:
        return HTTPBasicAuth(username, password)
    else:
        return None


def get(url, headers={}, auth_required=False):
    """ HTTP - GET request
    Arguments:
        - url: HTTP/S endpoint
        - headers: Request headers dictionary
        - auth_required: HTTP/S basic authentication required?
    Returns <Response> object
    """
    try:
        if auth_required:
            auth = get_basic_auth(username="", password="")
        else:
            auth = None
        res = requests.get(url, headers=headers, auth=auth)
    except requests.exceptions.ConnectionError as e:
        print(e)  # Handle with logger
    else:
        return res


def post(url, data=None, json=None, headers={}, auth_required=False):
    """ HTTP - POST request
    Arguments:
        - url: HTTP/S endpoint
        - data: Request payload [Optional] - Dict/ Bytes/ File object
        - json: JSON data [Optional]
        - headers: Request headers dictionary
        - auth_required: HTTP/S basic authentication required?
    Returns <Response> object
    """
    try:
        if auth_required:
            auth = get_basic_auth(username="", password="")
        else:
            auth = None
        res = requests.post(url, data=data, json=json,
                            headers=headers, auth=auth)
    except requests.exceptions.ConnectionError as e:
        print(e)  # Handle with logger
    else:
        return res


def put(url, data=None, json=None, headers={}, auth_required=False):
    """ HTTP - PUT request
    Arguments:
        - url: HTTP/S endpoint
        - data: Request payload [Optional] - Dict/ Bytes/ File object
        - json: JSON data [Optional]
        - headers: Request headers dictionary
        - auth_required: HTTP/S basic authentication required?
    Returns <Response> object
    """
    try:
        if auth_required:
            auth = get_basic_auth(username="", password="")
        else:
            auth = None
        res = requests.put(url, data, headers=headers, auth=auth)
    except requests.exceptions.ConnectionError as e:
        print(e)  # Handle with logger
    else:
        return res


def delete(url, cookies={}, headers={}, auth_required=False):
    """ HTTP - DELETE request
    Arguments:
        - url: HTTP/S endpoint
        - headers: Request headers dictionary
        - auth_required: HTTP/S basic authentication required?
    Returns <Response> object
    """
    try:
        if auth_required:
            auth = get_basic_auth(username="", password="")
        else:
            auth = None
        res = requests.delete(url, headers=headers, auth=auth)
    except requests.exceptions.ConnectionError as e:
        print(e)  # Handle with logger
    else:
        return res


def log_request(req):
    """ Log request sent through HTTP/S API
    Arguments:
        - req: <Request> object (Eg: res.request)
    Returns printable logger string of request
    """
    request_header = '\n{0}\nREQUEST SENT\n{0}\n'.format('-' * 12)
    logline = ''.join([
        request_header,
        'request method..: {0}\n'.format(req.method),
        'request full url: {0}\n'.format(req.url),
        'request headers.: {0}\n'.format(req.headers),
        'request body....: {0}\n'.format(req.body)])
    return logline


def log_response(resp):
    """ Log response sent through HTTP/S API
    Arguments:
        - resp: <Response> object (Eg: res)
    Returns printable logger string of response
    """
    response_header = '\n{0}\nRESPONSE RECEIVED\n{0}\n'.format('-' * 17)
    logline = ''.join([
        response_header,
        'response status..: {0} {1}\n'.format(resp, resp.reason),
        'response time....: {0}s\n'.format(resp.elapsed.total_seconds()),
        'response headers.: {0}\n'.format(resp.headers),
        'response body....: {0}\n'.format(resp.content),
        '-' * 79])
    return logline
